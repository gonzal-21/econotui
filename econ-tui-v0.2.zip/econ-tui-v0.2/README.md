# econ-tui v0.2

TUI económica para consultar UF, UTM y Dólar observado desde `mindicador.cl`.

## Funciones v0.2

- Selector de indicador con `h/l` o flechas.
- Selector de rango `1D/1S/1M/3M/6M/1A/MAX` con `[` y `]`.
- El rango persiste al cambiar indicador.
- Chart Braille y estadísticas calculados exclusivamente sobre el rango visible.
- Red asíncrona separada del hilo bloqueante de terminal.
- Cancelación lógica mediante identificador de petición.
- Último dato válido conservado ante errores de actualización.

## Compilar

```bash
cargo build --release
cargo run --release
```

## Atajos

- `h`, `←`: indicador anterior
- `l`, `→`: indicador siguiente
- `[`, `]`: rango anterior/siguiente
- `r`, `Ctrl+R`: actualizar
- `F1`, `?`: ayuda
- `Esc`: cerrar ayuda
- `q`: salir

## Verificación

```bash
cargo fmt --all --check
cargo test --all-targets
cargo clippy --all-targets --all-features -- -D warnings
```
