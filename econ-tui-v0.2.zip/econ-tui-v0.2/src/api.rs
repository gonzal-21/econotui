use crate::domain::{DataPoint, DomainError, Indicator, Series};
use chrono::{DateTime, Utc};
use reqwest::StatusCode;
use serde::Deserialize;
use std::{sync::Arc, time::Duration};
use thiserror::Error;

const BASE_URL: &str = "https://mindicador.cl/api";
const REQUEST_TIMEOUT: Duration = Duration::from_secs(5);

#[derive(Clone)]
pub struct MindicadorClient {
    client: reqwest::Client,
    base_url: Arc<str>,
}

impl MindicadorClient {
    pub fn new() -> Result<Self, ApiError> {
        Self::with_base_url(BASE_URL)
    }

    pub fn with_base_url(base_url: impl Into<Arc<str>>) -> Result<Self, ApiError> {
        let client = reqwest::Client::builder()
            .connect_timeout(REQUEST_TIMEOUT)
            .timeout(REQUEST_TIMEOUT)
            .pool_max_idle_per_host(1)
            .user_agent("econ-tui/0.2")
            .build()?;
        Ok(Self { client, base_url: base_url.into() })
    }

    pub async fn fetch(&self, indicator: Indicator) -> Result<Arc<Series>, ApiError> {
        let url = format!("{}/{}", self.base_url.trim_end_matches('/'), indicator.slug());
        let response = self.client.get(url).send().await?;
        let status = response.status();

        if status == StatusCode::NOT_FOUND {
            return Err(ApiError::NotFound(indicator));
        }
        if !status.is_success() {
            return Err(ApiError::HttpStatus(status.as_u16()));
        }

        let payload: ApiResponse = response.json().await?;
        if payload.serie.is_empty() {
            return Err(ApiError::EmptyResponse);
        }

        let points = payload
            .serie
            .into_iter()
            .map(|point| DataPoint { date: point.fecha.date_naive(), value: point.valor })
            .collect();

        Ok(Arc::new(Series::try_new(indicator, points)?))
    }
}

#[derive(Debug, Deserialize)]
struct ApiResponse {
    serie: Vec<ApiPoint>,
}

#[derive(Debug, Deserialize)]
struct ApiPoint {
    fecha: DateTime<Utc>,
    valor: f64,
}

#[derive(Debug, Error)]
pub enum ApiError {
    #[error("error HTTP: {0}")]
    Network(#[from] reqwest::Error),
    #[error("la API respondió HTTP {0}")]
    HttpStatus(u16),
    #[error("{0} no está disponible")]
    NotFound(Indicator),
    #[error("la API devolvió una serie vacía")]
    EmptyResponse,
    #[error(transparent)]
    Domain(#[from] DomainError),
}
