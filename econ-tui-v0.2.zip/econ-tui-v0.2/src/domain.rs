use chrono::{Duration, NaiveDate};
use serde::{Deserialize, Serialize};
use std::{fmt, str::FromStr, sync::Arc};
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Indicator {
    Uf,
    Utm,
    Dolar,
}

impl Indicator {
    pub const ALL: [Self; 3] = [Self::Uf, Self::Utm, Self::Dolar];

    #[must_use]
    pub const fn slug(self) -> &'static str {
        match self {
            Self::Uf => "uf",
            Self::Utm => "utm",
            Self::Dolar => "dolar",
        }
    }

    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::Uf => "UF",
            Self::Utm => "UTM",
            Self::Dolar => "Dólar observado",
        }
    }
}

impl fmt::Display for Indicator {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.label())
    }
}

impl FromStr for Indicator {
    type Err = DomainError;

    fn from_str(input: &str) -> Result<Self, Self::Err> {
        match input.trim().to_ascii_lowercase().as_str() {
            "uf" => Ok(Self::Uf),
            "utm" => Ok(Self::Utm),
            "dolar" | "dólar" | "usd" => Ok(Self::Dolar),
            _ => Err(DomainError::UnknownIndicator),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TimeRange {
    D1,
    W1,
    M1,
    M3,
    M6,
    Y1,
    Max,
}

impl TimeRange {
    pub const ALL: [Self; 7] = [
        Self::D1,
        Self::W1,
        Self::M1,
        Self::M3,
        Self::M6,
        Self::Y1,
        Self::Max,
    ];

    #[must_use]
    pub const fn days(self) -> Option<u32> {
        match self {
            Self::D1 => Some(1),
            Self::W1 => Some(7),
            Self::M1 => Some(30),
            Self::M3 => Some(90),
            Self::M6 => Some(180),
            Self::Y1 => Some(365),
            Self::Max => None,
        }
    }

    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::D1 => "1D",
            Self::W1 => "1S",
            Self::M1 => "1M",
            Self::M3 => "3M",
            Self::M6 => "6M",
            Self::Y1 => "1A",
            Self::Max => "MAX",
        }
    }

    #[must_use]
    pub fn previous(self) -> Self {
        let index = Self::ALL.iter().position(|candidate| *candidate == self).unwrap_or(0);
        Self::ALL[index.saturating_sub(1)]
    }

    #[must_use]
    pub fn next(self) -> Self {
        let index = Self::ALL.iter().position(|candidate| *candidate == self).unwrap_or(0);
        Self::ALL[(index + 1).min(Self::ALL.len() - 1)]
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct DataPoint {
    pub date: NaiveDate,
    pub value: f64,
}

#[derive(Debug, Clone)]
pub struct Series {
    indicator: Indicator,
    points: Arc<[DataPoint]>,
}

impl Series {
    pub fn try_new(indicator: Indicator, mut points: Vec<DataPoint>) -> Result<Self, DomainError> {
        if points.is_empty() {
            return Err(DomainError::EmptySeries);
        }
        if points.iter().any(|point| !point.value.is_finite()) {
            return Err(DomainError::NonFinite);
        }
        points.sort_unstable_by_key(|point| point.date);
        if points.windows(2).any(|pair| pair[0].date == pair[1].date) {
            return Err(DomainError::DuplicateDate);
        }
        Ok(Self { indicator, points: points.into() })
    }

    #[must_use]
    pub const fn indicator(&self) -> Indicator {
        self.indicator
    }

    #[must_use]
    pub fn points(&self) -> &[DataPoint] {
        &self.points
    }

    #[must_use]
    pub fn visible(&self, range: TimeRange) -> &[DataPoint] {
        let Some(days) = range.days() else {
            return &self.points;
        };
        let Some(last) = self.points.last() else {
            return &[];
        };

        // Para una serie diaria, 1D incluye la última observación y la anterior,
        // de modo que la variación y la línea sigan siendo informativas.
        let calendar_days = i64::from(days.max(1));
        let threshold = last.date - Duration::days(calendar_days);
        let start = self.points.partition_point(|point| point.date < threshold);
        &self.points[start..]
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VisibleStats {
    pub observations: u32,
    pub first: f64,
    pub last: f64,
    pub min: f64,
    pub max: f64,
    pub absolute_change: f64,
    pub percentage_change: Option<f64>,
    pub mean: f64,
}

impl VisibleStats {
    pub fn from_points(points: &[DataPoint]) -> Option<Self> {
        let first = points.first()?.value;
        let last = points.last()?.value;
        let mut min = first;
        let mut max = first;
        let mut sum = 0.0;

        for point in points {
            min = min.min(point.value);
            max = max.max(point.value);
            sum += point.value;
        }

        let percentage_change = if first.abs() <= f64::EPSILON {
            None
        } else {
            Some((last / first - 1.0) * 100.0)
        };

        Some(Self {
            observations: u32::try_from(points.len()).unwrap_or(u32::MAX),
            first,
            last,
            min,
            max,
            absolute_change: last - first,
            percentage_change,
            mean: sum / points.len() as f64,
        })
    }
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum DomainError {
    #[error("indicador desconocido")]
    UnknownIndicator,
    #[error("la serie está vacía")]
    EmptySeries,
    #[error("la serie contiene un valor no finito")]
    NonFinite,
    #[error("la serie contiene fechas duplicadas")]
    DuplicateDate,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn date(day: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(2026, 1, day).expect("fecha válida")
    }

    fn sample_series() -> Series {
        Series::try_new(
            Indicator::Uf,
            (1..=10).map(|day| DataPoint { date: date(day), value: f64::from(day) }).collect(),
        )
        .expect("serie válida")
    }

    #[test]
    fn ranges_are_saturated_at_edges() {
        assert_eq!(TimeRange::D1.previous(), TimeRange::D1);
        assert_eq!(TimeRange::Max.next(), TimeRange::Max);
    }

    #[test]
    fn max_returns_complete_series() {
        assert_eq!(sample_series().visible(TimeRange::Max).len(), 10);
    }

    #[test]
    fn one_day_keeps_two_daily_observations() {
        let visible = sample_series().visible(TimeRange::D1);
        assert_eq!(visible.len(), 2);
        assert_eq!(visible[0].date, date(9));
    }

    #[test]
    fn visible_stats_use_only_given_slice() {
        let series = sample_series();
        let stats = VisibleStats::from_points(series.visible(TimeRange::D1)).expect("estadísticas");
        assert_eq!(stats.observations, 2);
        assert_eq!(stats.first, 9.0);
        assert_eq!(stats.last, 10.0);
    }

    #[test]
    fn constructor_sorts_points() {
        let series = Series::try_new(
            Indicator::Uf,
            vec![DataPoint { date: date(2), value: 2.0 }, DataPoint { date: date(1), value: 1.0 }],
        )
        .expect("serie válida");
        assert_eq!(series.points()[0].date, date(1));
    }

    #[test]
    fn constructor_rejects_duplicates_and_non_finite_values() {
        let duplicate = Series::try_new(
            Indicator::Uf,
            vec![DataPoint { date: date(1), value: 1.0 }, DataPoint { date: date(1), value: 2.0 }],
        );
        assert_eq!(duplicate.expect_err("debe fallar"), DomainError::DuplicateDate);

        let non_finite = Series::try_new(
            Indicator::Uf,
            vec![DataPoint { date: date(1), value: f64::NAN }],
        );
        assert_eq!(non_finite.expect_err("debe fallar"), DomainError::NonFinite);
    }
}
