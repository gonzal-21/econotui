mod api;
mod domain;
mod ui;

use api::{ApiError, MindicadorClient};
use crossterm::{
    event::{self, Event, KeyCode, KeyEvent, KeyEventKind, KeyModifiers},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use domain::{Indicator, Series};
use ratatui::{backend::CrosstermBackend, Terminal};
use std::{io::{self, stdout}, process::ExitCode, sync::Arc, thread, time::Duration};
use tokio::sync::mpsc;
use ui::AppState;

const EVENT_CAPACITY: usize = 32;
const FRAME_PERIOD: Duration = Duration::from_micros(16_667);

enum AppEvent {
    Terminal(Event),
    Data {
        request_id: u64,
        indicator: Indicator,
        result: Result<Arc<Series>, ApiError>,
    },
    InputClosed,
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> ExitCode {
    match run().await {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("econ-tui: {error}");
            ExitCode::FAILURE
        }
    }
}

async fn run() -> Result<(), AppError> {
    let client = MindicadorClient::new()?;
    let mut guard = TerminalGuard::enter()?;
    let backend = CrosstermBackend::new(stdout());
    let mut terminal = Terminal::new(backend)?;
    terminal.clear()?;

    let (event_tx, mut event_rx) = mpsc::channel(EVENT_CAPACITY);
    let input_thread = spawn_input_thread(event_tx.clone());
    let mut state = AppState::new();
    start_fetch(&mut state, &client, &event_tx);

    let mut frame_tick = tokio::time::interval(FRAME_PERIOD);
    frame_tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    while !state.quit {
        tokio::select! {
            maybe_event = event_rx.recv() => {
                match maybe_event {
                    Some(AppEvent::Terminal(event)) => {
                        handle_terminal_event(event, &mut state, &client, &event_tx);
                    }
                    Some(AppEvent::Data { request_id, indicator, result }) => {
                        // Descarta respuestas tardías de un indicador o petición anterior.
                        if request_id == state.request_id && indicator == state.indicator() {
                            state.loading = false;
                            match result {
                                Ok(series) => {
                                    state.series = Some(series);
                                    state.error = None;
                                    state.stale = false;
                                    state.last_update = Some(std::time::Instant::now());
                                }
                                Err(error) => {
                                    state.stale = state.series.is_some();
                                    state.error = Some(Arc::new(error));
                                }
                            }
                            state.dirty = true;
                        }
                    }
                    Some(AppEvent::InputClosed) | None => state.quit = true,
                }
            }
            _ = frame_tick.tick(), if state.dirty => {
                terminal.draw(|frame| ui::draw(frame, &state))?;
                state.dirty = false;
            }
            result = tokio::signal::ctrl_c() => {
                result?;
                state.quit = true;
            }
        }
    }

    drop(event_rx);
    drop(event_tx);
    let _ = input_thread.join();
    guard.restore()?;
    Ok(())
}

fn handle_terminal_event(
    event: Event,
    state: &mut AppState,
    client: &MindicadorClient,
    event_tx: &mpsc::Sender<AppEvent>,
) {
    let Event::Key(KeyEvent { code, modifiers, kind, .. }) = event else {
        return;
    };
    if kind != KeyEventKind::Press {
        return;
    }

    if state.help_open {
        match code {
            KeyCode::Esc | KeyCode::Char('?') | KeyCode::F(1) => {
                state.help_open = false;
                state.dirty = true;
            }
            KeyCode::Char('q') => state.quit = true,
            _ => {}
        }
        return;
    }

    match (code, modifiers) {
        (KeyCode::Char('q'), _) => state.quit = true,
        (KeyCode::Esc, _) => state.quit = true,
        (KeyCode::Char('?'), _) | (KeyCode::F(1), _) => {
            state.help_open = true;
            state.dirty = true;
        }
        (KeyCode::Char('['), _) => state.previous_range(),
        (KeyCode::Char(']'), _) => state.next_range(),
        (KeyCode::Left | KeyCode::Char('h'), _) => {
            let before = state.indicator();
            state.previous_indicator();
            if state.indicator() != before {
                start_fetch(state, client, event_tx);
            }
        }
        (KeyCode::Right | KeyCode::Char('l'), _) => {
            let before = state.indicator();
            state.next_indicator();
            if state.indicator() != before {
                start_fetch(state, client, event_tx);
            }
        }
        (KeyCode::Char('r'), _) | (KeyCode::Char('R'), KeyModifiers::CONTROL) => {
            start_fetch(state, client, event_tx);
        }
        _ => {}
    }
}

fn start_fetch(state: &mut AppState, client: &MindicadorClient, event_tx: &mpsc::Sender<AppEvent>) {
    state.request_id = state.request_id.wrapping_add(1);
    let request_id = state.request_id;
    let indicator = state.indicator();
    state.loading = true;
    state.error = None;
    state.dirty = true;

    let client = client.clone();
    let event_tx = event_tx.clone();
    tokio::spawn(async move {
        let result = client.fetch(indicator).await;
        let _ = event_tx.send(AppEvent::Data { request_id, indicator, result }).await;
    });
}

fn spawn_input_thread(event_tx: mpsc::Sender<AppEvent>) -> thread::JoinHandle<()> {
    thread::Builder::new()
        .name("terminal-input".to_owned())
        .spawn(move || loop {
            match event::poll(Duration::from_millis(50)) {
                Ok(true) => match event::read() {
                    Ok(event) => {
                        if event_tx.blocking_send(AppEvent::Terminal(event)).is_err() {
                            break;
                        }
                    }
                    Err(_) => {
                        let _ = event_tx.blocking_send(AppEvent::InputClosed);
                        break;
                    }
                },
                Ok(false) => {
                    if event_tx.is_closed() {
                        break;
                    }
                }
                Err(_) => {
                    let _ = event_tx.blocking_send(AppEvent::InputClosed);
                    break;
                }
            }
        })
        .expect("no se pudo crear el hilo de terminal")
}

struct TerminalGuard {
    active: bool,
}

impl TerminalGuard {
    fn enter() -> io::Result<Self> {
        enable_raw_mode()?;
        if let Err(error) = execute!(stdout(), EnterAlternateScreen) {
            let _ = disable_raw_mode();
            return Err(error);
        }
        Ok(Self { active: true })
    }

    fn restore(&mut self) -> io::Result<()> {
        if self.active {
            execute!(stdout(), LeaveAlternateScreen)?;
            disable_raw_mode()?;
            self.active = false;
        }
        Ok(())
    }
}

impl Drop for TerminalGuard {
    fn drop(&mut self) {
        let _ = self.restore();
    }
}

#[derive(Debug, thiserror::Error)]
enum AppError {
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error(transparent)]
    Api(#[from] ApiError),
}
