use crate::{
    api::ApiError,
    domain::{Indicator, Series, TimeRange, VisibleStats},
};
use ratatui::{
    layout::{Constraint, Layout, Rect},
    prelude::*,
    symbols::Marker,
    widgets::{Axis, Block, Borders, Chart, Dataset, GraphType, Paragraph, Row, Table},
};
use std::{sync::Arc, time::Instant};

pub struct AppState {
    pub selected_index: usize,
    pub range: TimeRange,
    pub series: Option<Arc<Series>>,
    pub loading: bool,
    pub stale: bool,
    pub error: Option<Arc<ApiError>>,
    pub help_open: bool,
    pub dirty: bool,
    pub quit: bool,
    pub request_id: u64,
    pub last_update: Option<Instant>,
}

impl AppState {
    #[must_use]
    pub fn new() -> Self {
        Self {
            selected_index: 0,
            range: TimeRange::M1,
            series: None,
            loading: false,
            stale: false,
            error: None,
            help_open: false,
            dirty: true,
            quit: false,
            request_id: 0,
            last_update: None,
        }
    }

    #[must_use]
    pub fn indicator(&self) -> Indicator {
        Indicator::ALL[self.selected_index]
    }

    pub fn previous_indicator(&mut self) {
        self.selected_index = self.selected_index.saturating_sub(1);
        self.dirty = true;
    }

    pub fn next_indicator(&mut self) {
        self.selected_index = (self.selected_index + 1).min(Indicator::ALL.len() - 1);
        self.dirty = true;
    }

    pub fn previous_range(&mut self) {
        self.range = self.range.previous();
        self.dirty = true;
    }

    pub fn next_range(&mut self) {
        self.range = self.range.next();
        self.dirty = true;
    }
}

pub fn draw(frame: &mut Frame<'_>, state: &AppState) {
    let area = frame.area();
    let [header, chart, stats, status] = Layout::vertical([
        Constraint::Length(3),
        Constraint::Min(8),
        Constraint::Length(6),
        Constraint::Length(2),
    ])
    .areas(area);

    draw_header(frame, header, state);
    draw_chart(frame, chart, state);
    draw_stats(frame, stats, state);
    draw_status(frame, status, state);

    if state.help_open {
        draw_help(frame, centered_rect(70, 60, area));
    }
}

fn draw_header(frame: &mut Frame<'_>, area: Rect, state: &AppState) {
    let text = Line::from(vec![
        Span::styled(" ECON-TUI ", Style::default().fg(Color::Black).bg(Color::Cyan).bold()),
        Span::raw("  "),
        Span::styled(state.indicator().label(), Style::default().fg(Color::White).bold()),
        Span::raw("  "),
        Span::styled(
            format!("[{}]", state.range.label()),
            Style::default().fg(Color::Yellow).bold(),
        ),
    ]);
    frame.render_widget(Paragraph::new(text).block(Block::default().borders(Borders::BOTTOM)), area);
}

fn draw_chart(frame: &mut Frame<'_>, area: Rect, state: &AppState) {
    let title = format!(" {} · rango {} ", state.indicator().label(), state.range.label());
    let Some(series) = state.series.as_ref() else {
        let message = if state.loading { "Consultando mindicador.cl…" } else { "Sin datos" };
        frame.render_widget(Paragraph::new(message).block(Block::bordered().title(title)), area);
        return;
    };

    let visible = series.visible(state.range);
    if visible.is_empty() {
        frame.render_widget(Paragraph::new("Sin observaciones para el rango").block(Block::bordered().title(title)), area);
        return;
    }

    let chart_points: Vec<(f64, f64)> = visible
        .iter()
        .enumerate()
        .map(|(index, point)| (index as f64, point.value))
        .collect();
    let stats = VisibleStats::from_points(visible).expect("visible no está vacío");
    let padding = ((stats.max - stats.min) * 0.05).max(stats.max.abs() * 0.001).max(0.01);
    let end = chart_points.len().saturating_sub(1).max(1) as f64;

    let dataset = Dataset::default()
        .name(state.indicator().label())
        .marker(Marker::Braille)
        .graph_type(GraphType::Line)
        .style(Style::default().fg(Color::Cyan))
        .data(&chart_points);

    let chart = Chart::new(vec![dataset])
        .block(Block::bordered().title(title))
        .x_axis(Axis::default().bounds([0.0, end]))
        .y_axis(Axis::default().bounds([stats.min - padding, stats.max + padding]));

    frame.render_widget(chart, area);
}

fn draw_stats(frame: &mut Frame<'_>, area: Rect, state: &AppState) {
    let Some(series) = state.series.as_ref() else {
        frame.render_widget(Block::bordered().title(" Estadísticas visibles "), area);
        return;
    };
    let visible = series.visible(state.range);
    let Some(stats) = VisibleStats::from_points(visible) else {
        frame.render_widget(Block::bordered().title(" Estadísticas visibles "), area);
        return;
    };

    let percentage = stats
        .percentage_change
        .map_or_else(|| "n/d".to_owned(), |value| format!("{value:+.3}%"));
    let trend = if stats.absolute_change > 0.0 {
        Span::styled("↑", Style::default().fg(Color::Green).bold())
    } else if stats.absolute_change < 0.0 {
        Span::styled("↓", Style::default().fg(Color::Red).bold())
    } else {
        Span::styled("→", Style::default().fg(Color::Yellow).bold())
    };

    let rows = [
        Row::new(vec!["Observaciones".to_owned(), stats.observations.to_string(), "Rango".to_owned(), state.range.label().to_owned()]),
        Row::new(vec!["Inicial".to_owned(), format!("{:.3}", stats.first), "Final".to_owned(), format!("{:.3}", stats.last)]),
        Row::new(vec!["Mínimo".to_owned(), format!("{:.3}", stats.min), "Máximo".to_owned(), format!("{:.3}", stats.max)]),
        Row::new(vec!["Media".to_owned(), format!("{:.3}", stats.mean), "Variación".to_owned(), percentage]),
    ];
    let table = Table::new(rows, [Constraint::Length(14), Constraint::Percentage(35), Constraint::Length(12), Constraint::Percentage(35)])
        .block(Block::bordered().title(Line::from(vec![Span::raw(" Estadísticas visibles "), trend])));
    frame.render_widget(table, area);
}

fn draw_status(frame: &mut Frame<'_>, area: Rect, state: &AppState) {
    let status = if state.loading {
        Span::styled("⟳ actualizando", Style::default().fg(Color::Yellow))
    } else if state.stale {
        Span::styled("▲ stale", Style::default().fg(Color::Yellow).bold())
    } else if state.error.is_some() {
        Span::styled("× error", Style::default().fg(Color::Red).bold())
    } else {
        Span::styled("● listo", Style::default().fg(Color::Green))
    };

    let mut spans = vec![status, Span::raw("  h/l indicador  [/] rango  r refrescar  ? ayuda  q salir")];
    if let Some(error) = &state.error {
        spans.push(Span::styled(format!("  · {error}"), Style::default().fg(Color::Red)));
    }
    frame.render_widget(Paragraph::new(Line::from(spans)).block(Block::default().borders(Borders::TOP)), area);
}

fn draw_help(frame: &mut Frame<'_>, area: Rect) {
    frame.render_widget(ratatui::widgets::Clear, area);
    let help = [
        Line::from("h / ←      Indicador anterior"),
        Line::from("l / →      Indicador siguiente"),
        Line::from("[ / ]      Rango anterior/siguiente"),
        Line::from("r / Ctrl+R Actualizar"),
        Line::from("F1 / ?     Abrir ayuda"),
        Line::from("Esc        Cerrar ayuda"),
        Line::from("q          Salir"),
        Line::from(""),
        Line::from("Las estadísticas y el gráfico usan exclusivamente el rango visible."),
    ];
    frame.render_widget(Paragraph::new(help).block(Block::bordered().title(" Ayuda v0.2 ")), area);
}

fn centered_rect(percent_x: u16, percent_y: u16, area: Rect) -> Rect {
    let vertical = Layout::vertical([
        Constraint::Percentage((100 - percent_y) / 2),
        Constraint::Percentage(percent_y),
        Constraint::Percentage((100 - percent_y) / 2),
    ])
    .split(area);
    Layout::horizontal([
        Constraint::Percentage((100 - percent_x) / 2),
        Constraint::Percentage(percent_x),
        Constraint::Percentage((100 - percent_x) / 2),
    ])
    .split(vertical[1])[1]
}
